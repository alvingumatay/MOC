<?php
error_reporting(0);
// panggil fungsi validasi xss dan injection
require_once('fungsi_validasi.php');

// definisikan koneksi ke database
$server = "sql312.byethost.com";
$username = "b13_24703675";
$password = "marikina12345";
$database = "b13_24703675_hcpms";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");

// buat variabel untuk validasi dari file fungsi_validasi.php
$val = new validasi;
?>
