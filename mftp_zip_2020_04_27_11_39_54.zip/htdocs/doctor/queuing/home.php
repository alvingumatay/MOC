<?php
//$no_visible_elements=true;
session_start();
error_reporting(0);
include('headerHome.php'); ?>

 <div id="main-container">
        
       <?php  include "root/content_home.php"; ?>
        
    </div>
    <!-- // main-container  --> 
    
</div>
<!-- // page-container --> 


<?php include('footer.php'); ?>
