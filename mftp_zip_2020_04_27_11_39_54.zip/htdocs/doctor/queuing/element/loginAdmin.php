

 <div id="main-container">
        <div id="main-content" class="main-content container">
            <div class="signin-content">
               <br/> <br/><br/> <br/>
                <div class="well well-nice form-dark">
                    <div class="tab-content overflow">
                        <div class="tab-pane fade in active" id="login">
                            <h5 class="no-margin-top"><i class="fontello-icon-user-4"></i> Sign in with your Username</h5>
                            
                                <form class="form-tied margin-00" action="element/cek_login_admin.php" method="post">
                                <fieldset>
                                    
                                    <ul>
                                        <li>
                                            <input autofocus id="idLogin" class="input-block-level" type="text" name="username" placeholder="your ID or Username" required>
                                            
                                        </li>
                                        <li>
                                            <input id="idPassword" class="input-block-level" type="password" name="password" placeholder="password" required>
                                            
                                        </li>
                                    </ul>
                                    <button type="submit" class="btn btn-envato btn-block btn-large">SIGN IN</button>
                                    <hr class="margin-xm">
                                    
                                </fieldset>
                            </form>
                            <!-- // form --> 
                            
                        </div>
                        <!-- // Tab Login -->
                        
                        
                        
                       
                        
                    </div>
                </div>
                <!-- // Well-Nice -->                 
                
                
                
            </div>
            <!-- // sign-content --> 
            
        </div>
        <!-- // main-content --> 
        
    </div>
    <!-- // main-container  --> 
    
</div>
<!-- // page-container --> 
