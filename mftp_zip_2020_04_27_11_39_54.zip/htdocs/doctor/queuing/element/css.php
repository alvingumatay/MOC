<meta charset="utf-8">
<title>MOSC Patient | Record System
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="description" content="">
<meta name="author" content="">

<!-- Custom styles -->
<style type="text/css">
.signin-content {
  max-width: 360px;
  margin: 0 auto 20px;
}
</style>

<!-- Le styles -->
<link href="webroot/css/lib/bootstrap.css" rel="stylesheet">
<link href="webroot/css/lib/bootstrap-responsive.css" rel="stylesheet">
<link href="webroot/css/boo-extension.css" rel="stylesheet">
<link href="webroot/css/boo.css" rel="stylesheet">
<link href="webroot/css/style.css" rel="stylesheet">
<link href="webroot/css/boo-coloring.css" rel="stylesheet">
<link href="webroot/css/boo-utility.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>

<![endif]-->

<!-- Le fav and touch icons -->
<link rel="shortcut icon" href="webroot/ico/mosc-logo.png">

<!-- Placed at the end of the document so the pages load faster --> 
<script src="webroot/js/lib/jquery.js"></script> 
<script src="webroot/js/lib/jquery-ui.js"></script>
<script src="webroot/js/lib/jquery.cookie.js"></script> 

<script src="webroot/js/lib/bootstrap/bootstrap.js"></script>  
<!-- Plugins Tables --> 
<script src="webroot/plugins/pl-table/datatables/media/js/jquery.dataTables.js"></script> 
<script src="webroot/plugins/pl-table/datatables/plugin/jquery.dataTables.plugins.js"></script> 
<script src="webroot/plugins/pl-table/datatables/plugin/jquery.dataTables.columnFilter.js"></script> 