 <ul class="nav pull-right ">
                                
                                <li> <a href="?link=loginAdmin"><small>Login Admin</small></a> </li>
                                
                            </ul>