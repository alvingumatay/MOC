<div id="page-content" class="page-content">
                <nav>
                
                    <ul class="nav nav-center " style="margin-top: 120px">
                       <li><a class="btn btn-well btn-glyph" href="lcd.php" style="width:82px"><i class="  fontello-icon-monitor f30"></i><span class="block"> LCD SCREEN</span></a></li>
                        
                        <li><a class="btn btn-well btn-glyph" href="?link=loginAdmin" style="width:82px" data-toggle="modal"><i class=" fontello-icon-mobile f30"></i><span class="block">COUNTER VIEW</span></a></li>
                        
                        
                    </ul>
                
                     </nav>
                
            </div>
            <!-- // page content --> 
            