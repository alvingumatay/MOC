<?php 
header('location:home.php?link=home');
?>