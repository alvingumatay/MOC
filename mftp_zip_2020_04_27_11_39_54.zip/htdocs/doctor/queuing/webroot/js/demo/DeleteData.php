<script>
    alert('Are You Sure ??');
    </script>
<?php
  //DeleteData.php
  $id = $_REQUEST['id'] ;

  /* Delete a record by id */ 

  echo "ok";

?>