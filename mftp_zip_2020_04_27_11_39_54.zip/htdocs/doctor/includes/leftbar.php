<nav class="ts-sidebar">
<br/> <br/><br/><br/> <br/>
			<ul class="ts-sidebar-menu">
				<li><a href = "doctor_appointment.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
			   <li><a href = "rehabilitation.php"><i class = "glyphicon glyphicon-calendar"></i> Consultation</a></li>	
			   <li><a href = "minor_surgery.php"><i class = "glyphicon glyphicon-calendar"></i> Minor Surgery</a></li>	
			  <li><a href = "dislocation.php"><i class = "glyphicon glyphicon-calendar"></i> Dislocation</a></li>	
              <li><a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> logout</a></li>	
		  </ul>
	</nav>