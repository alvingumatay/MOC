<nav class="ts-sidebar">
<br/> <br/><br/><br/> <br/>
			<ul class="ts-sidebar-menu">
				<li><a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> logout</a></li>	
		  </ul>
	</nav>