<?php
	$conn = new mysqli("sql312.byethost.com","b13_24703675","marikina12345","b13_24703675_hcpms") or die(mysqli_error());
	$conn->query("DELETE FROM `secretary` WHERE `sec_id` = '$_GET[id]'") or die(mysqli_error());
	header("location:secretary.php");
