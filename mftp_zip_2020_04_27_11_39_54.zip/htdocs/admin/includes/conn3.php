<?php
	$host = 'sql312.byethost.com';
	$user = 'b13_24703675';
	$pass = 'marikina12345';
	$db = 'b13_24703675_hcpms';
	
?>