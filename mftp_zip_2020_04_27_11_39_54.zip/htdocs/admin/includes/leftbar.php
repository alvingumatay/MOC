<nav class="ts-sidebar">
<ul class="ts-sidebar-menu">
<br/> <br/><br/> 
				<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = "patient.php"><i class = "glyphicon glyphicon-user"></i> Patient</a></li>
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Accounts</a>
					<ul>
						<li><a href = "admin.php"><i class = "glyphicon glyphicon-cog"></i> Administrator</a></li>
						<li><a href = "user.php"><i class = "glyphicon glyphicon-cog"></i> Doctor</a></li>
						<li><a href = "secretary.php"><i class = "glyphicon glyphicon-cog"></i> Secretary</a></li>
					</ul>
				</li>
				<li><a href = ""><i class = "glyphicon glyphicon-calendar"></i> Appointment</a>
					<ul>
						<li><a href = "appointment.php"><i class = "glyphicon glyphicon-paperclip"></i> Pending Appointment</a></li>
					    <li><a href = "approve_appoint.php"><i class = "glyphicon glyphicon-paperclip"></i> Approve Appointment</a></li>
                        <li><a href = "appoint.php"><i class = "glyphicon glyphicon-list"></i> Appointment History</a></li>
					</ul>
				</li>
				<li><a href = ""><i class = "glyphicon glyphicon-folder-close"></i> Sections</a>
					<ul>
						<li><a href = "rehabilitation.php"><i class = "glyphicon glyphicon-folder-open"></i> 
						    Consultation</a></li>

						<li><a href = "xray.php"><i class = "glyphicon glyphicon-folder-open"></i>
						    Xray</a></li>

						<li><a href = "fecalysis.php"><i class = "glyphicon glyphicon-folder-open"></i>  Fecalysis</a></li>

						<li><a href = "urinalysis.php"><i class = "glyphicon glyphicon-folder-open"></i>  Urinalysis</a></li>

						<li><a href = "hematology.php"><i class = "glyphicon glyphicon-folder-open"></i>  Hematology</a></li>
                        
                        <li><a href = "minor_surgery.php"><i class = "glyphicon glyphicon-folder-open"></i>  Minor Surgery</a></li>

                        <li><a href = "dislocation.php"><i class = "glyphicon glyphicon-folder-open"></i> Dislocation</a></li>
			             </ul>
				       </li>
				    <li><a href = ""><i class = "glyphicon glyphicon-wrench"></i> Settings</a>
					       <ul>
						     <li>
							<a href = "backuprestore.php"><i class = "glyphicon glyphicon-download-alt"></i> Backup Restore </a>
						      </li>
					       </ul>
				    </li>
                    <li><a href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a></li>
			</ul>
	</nav>