<?php
	$conn = new PDO( 'mysql:host=sql312.byethost.com;dbname=b13_24703675_hcpms', 'b13_24703675', 'marikina12345');
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>