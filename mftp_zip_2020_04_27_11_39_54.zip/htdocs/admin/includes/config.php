<?php
$mysqli = new mysqli("sql312.byethost.com","b13_24703675","marikina12345","b13_24703675_hcpms");
?>